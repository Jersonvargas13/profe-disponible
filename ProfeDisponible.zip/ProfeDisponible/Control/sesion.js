const PANTALLA_POR_ROL = {
    estudiante: "estudiante.html",
    profesor: "profesor.html",
    administrador: "administrador.html"
};

async function cerrarSesion() {
    try {
        await fetch("/api/logout", { method: "POST" });
    } catch (error) {
        console.error("No se pudo cerrar la sesión en el servidor.", error);
    }

    window.location.href = "index.html";
}

(async function protegerPantalla() {
    const rolRequerido = document.documentElement.dataset.rolRequerido;
    if (!rolRequerido) {
        return;
    }

    try {
        const respuesta = await fetch("/api/session");
        const resultado = await respuesta.json();

        if (!respuesta.ok || resultado.user.rol !== rolRequerido) {
            window.location.href = "login.html?rol=" + encodeURIComponent(rolRequerido);
            return;
        }
    } catch (error) {
        console.error("No se pudo verificar la sesión.", error);
        window.location.href = "login.html?rol=" + encodeURIComponent(rolRequerido);
    }
})();

document.addEventListener("DOMContentLoaded", function () {
    const botonSalir = document.getElementById("cerrar-sesion");
    if (botonSalir) {
        botonSalir.addEventListener("click", function (event) {
            event.preventDefault();
            cerrarSesion();
        });
    }
});
