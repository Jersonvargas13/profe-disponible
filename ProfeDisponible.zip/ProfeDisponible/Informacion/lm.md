# Configuración de la base de datos

## Requisitos

- MySQL Server iniciado. MySQL Workbench sirve para administrar la base, pero no
  reemplaza al servidor MySQL.
- Node.js 18 o una versión posterior.

## Puesta en marcha

1. Abre `base.sql` en MySQL Workbench y ejecuta el script completo. Crea la base
   `profedisponible`, sus tablas y tres cuentas de prueba.
2. Desde la carpeta raíz del proyecto, instala las dependencias:

   ```powershell
   npm.cmd install
   ```

3. Crea tu archivo local de configuración copiando `.env.example` como `.env`:

   ```powershell
   Copy-Item .env.example .env
   ```

   Ajusta `DB_USER`, `DB_PASSWORD` y los demás datos si tu MySQL no usa los
   valores de ejemplo. Si el usuario local `root` no tiene contraseña, deja
   `DB_PASSWORD` vacío. No compartas ni subas `.env`.
4. Inicia el sitio:

   ```powershell
   npm.cmd start
   ```

5. Abre `http://localhost:3000` en el navegador. No abras los HTML con doble clic:
   el navegador necesita comunicarse con el servidor para iniciar sesión y
   guardar cuentas.

   Si PowerShell dice que la ejecución de scripts está deshabilitada, usa
   `npm.cmd` como en estos ejemplos; no es necesario cambiar la política de
   seguridad. Si el servidor ya estaba ejecutándose, deténlo con `Ctrl+C` y
   vuelve a iniciarlo para que cargue los cambios.

## Cuentas de prueba

| Usuario | Rol | Contraseña |
|---|---|---|
| `estudiante1` | estudiante | `Estudiante#2026` |
| `profesor1` | profesor | `Profesor#2026` |
| `admin1` | administrador | `Admin#2026` |

Estas son cuentas académicas de demostración. Cámbialas antes de usar el sistema
con información real. El registro público solo permite crear estudiantes y
profesores; las cuentas de administrador deben crearse manualmente.

## Conexión

El servidor en `server.js` conecta la página con MySQL. La contraseña se procesa
en el servidor y se guarda como hash PBKDF2-SHA256; las sesiones usan una cookie
HTTP-only. No conectes MySQL directamente desde el navegador ni publiques las
credenciales de la base de datos.

## Funciones disponibles

- **Estudiante:** ve los horarios activos, solicita una asesoría futura de 30 o
  60 minutos y revisa o cancela solicitudes pendientes y aceptadas.
- **Profesor:** publica horarios semanales, desactiva los que ya no ofrece y
  acepta o rechaza solicitudes pendientes.
- **Administrador:** consulta usuarios y asesorías, cambia el estado de las
  solicitudes y activa o desactiva cuentas. No puede desactivar su propia cuenta
  ni al último administrador activo.

Los días de disponibilidad usan `1 = lunes` hasta `7 = domingo`. Las solicitudes
deben estar dentro del horario publicado y no pueden cruzarse con otra solicitud
pendiente o aceptada del profesor.
